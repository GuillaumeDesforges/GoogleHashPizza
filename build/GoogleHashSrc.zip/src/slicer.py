def get_all_local_slices(y, x, data):
    # TODO change to test
    return [[y, x, y, x]]